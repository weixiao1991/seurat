---
name: "\U0001F680Feature request"
about: Request a new feature
title: ''
labels: enhancement
assignees: ''

---

<!-- Kindly explain the new feature you would like and why this would be useful. -->
